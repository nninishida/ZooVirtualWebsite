document.addEventListener("DOMContentLoaded", function() {
	const form = document.getElementById("commentForm");
	const commentList = document.getElementById("commentList");

	// Função para buscar e exibir os comentários
	async function listarComentarios() {
		try {
			// Envia uma requisição GET para o backend para buscar os comentários
			const response = await fetch("http://localhost:8080/comentario"); // Alterar para o endpoint correto que retorna os comentários
			const comentarios = await response.json();

			commentList.innerHTML = '';

/*			// Adiciona cada comentário à lista
			comentarios.forEach(comentario => {
				const li = document.createElement('li');
				li.textContent = `Usuario: ${comentario.usuario} - Comentario:${comentario.comentario}`;
				commentList.appendChild(li);
			});
*/



			comentarios.forEach(comentario => {
				const li = document.createElement('li');

				// Criando o elemento para o nome do usuário
				const usuarioElement = document.createElement('strong');
				usuarioElement.textContent = `${comentario.usuario}`;

				// Criando o elemento para o comentário
				const comentarioElement = document.createElement('p');
				comentarioElement.textContent = `${comentario.comentario}`;

				// Adicionando os elementos ao item da lista
				li.appendChild(usuarioElement);
				li.appendChild(comentarioElement);

				// Adicionando o item da lista à lista principal
				commentList.appendChild(li);
			});


		} catch (error) {
			console.error("Erro ao buscar os comentários:", error);
			alert("Erro ao buscar os comentários.");
		}
	}

	// Chama a função listarComentarios quando a página for carregada
	listarComentarios();

	form.addEventListener("submit", async (event) => {
		event.preventDefault();

		const usuario = document.getElementById('usuario').value;
		const comentario = document.getElementById('comentario').value;

		if (!usuario || !comentario) {
			alert("Por favor, preencha todos os campos!");
			return;
		}

		try {
			const response = await fetch("http://localhost:8080/comentario", {
				method: "POST",
				headers: {
					"Content-Type": "application/json",
				},
				body: JSON.stringify({
					usuario: usuario,
					comentario: comentario,
				}),
			});

			if (response.ok) {
				alert("Comentário realizado com sucesso!");
				form.reset();
				listarComentarios(); // Atualiza a lista de comentários após o envio
			} else {
				const errorText = await response.text();
				alert(`Erro ao realizar o comentário: ${errorText}`);
			}
		} catch (error) {
			console.error("Erro ao realizar o comentário:", error);
			alert("Erro ao realizar o comentário. Confira os logs para mais detalhes.");
		}
	});
});
