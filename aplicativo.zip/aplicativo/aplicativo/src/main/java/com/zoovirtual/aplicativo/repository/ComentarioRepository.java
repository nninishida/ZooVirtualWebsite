package com.zoovirtual.aplicativo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.zoovirtual.aplicativo.entities.Comentario;

public interface ComentarioRepository extends JpaRepository<Comentario, Long> {

}
